# PSA Command tab



PSA Command is a Kairos Store tab for PSA staff. It drives PSA Sales and Taskbar together: one overview, confirmed changes in either system, Home cards, and the same operations as tools for Kairos chats and agents. Install it from **Tool Store > Tabs**. Nothing is sent anywhere until you save a connection.



## What it shows and does



- **Overview:** connection status for both systems; schools, closes this month and overdue counts; pipeline and accounts by rep (administrator PSA key); PSA and Taskbar overdue tasks side by side, each with **Mark done**; recent sales activity.

- **Actions:** create a task in PSA Sales or Taskbar, reassign a PSA school to a rep, log a call, meeting or note. Every change is previewed in a confirmation dialog and only sent after **Send change**.

- **Connections:** API address and key for each system. Keys are encrypted with this tab's own key (`api.encrypt`) in `data/tab-data/psa_command/connections.json`, scoped to your Kairos user, and never returned to the page or written to logs. The page shows "Saved; leave blank to keep".

- **Ask Kairos:** opens a PSA Command chat seeded with the latest overview, marked as untrusted data so Kairos asks before shell commands.

- **Home cards** (Settings > Layout > From your tabs, hidden until you show them): *Overdue sales tasks* (up to five, PSA and Taskbar badges) and *Closes this month* (or overdue totals for a non-admin key). Cards read only the cached overview; no network on Home.

- The overview is cached per user and refreshed when you press **Refresh**, after each confirmed change, every 15 minutes while the tab is on, and in the daily sync.



## Native PSA workflow (local 1.2 draft)



The PSA website is optional. In Connections, sign in with your PSA account inside Kairos. Passwords are transient; the private employee session is encrypted separately from the agent key. Choose only the permissions you need. Approved sending requires an explicit separate grant. Taskbar is optional.



In Outreach you can review an agent request's exact recipients, merged copy and PDFs, approve and queue, retry queueing an already approved request, read batch progress, cancel remaining mail, check/read replies, and manage follow-up enrollments. Admins can create/edit templates, upload reusable catalog PDFs and import template JSON. Automatic follow-ups require a separate, bounded authorization; approving an intro never authorizes follow-ups.



Use Connections > Use these tools in Kairos chats to register the local MCP bridge, then select that integration in the chat. The initial key is shown once for that setup; the tab never exposes the private human-session JWT through tools. Existing tool changes require review in Tool Store > Tools. The agent prepares and executes approved requests, while the human approves in the Kairos tab. This is not approval by typing an agent-supplied `confirm=true`.



An expired private session requires signing in again here, without minting another key. Sign out forgets that session only. Revoke this Kairos connection revokes its delegated key on PSA first, then forgets local credentials; network errors preserve the connection for retry. Other MCP installations retaining the same revoked key will also be denied by PSA. Other keys and separately approved sequences are unaffected; cancel those explicitly in Follow-up sequences. An in-flight SMTP message may finish.



This source is not production activation. Items 1-6 backend migrations/code and the separate worker must be released before these endpoints work. Source edits require approval of the tab's new fingerprint in Tool Store > Tabs > Yours; previously loaded Python code requires a Kairos restart. No live connection or send was made by this development pass.



## Setup



1. **PSA Sales key:** in PSA Sales, open **Settings > AI & integrations**, create a key (start with Read only), and copy it. API address: `https://psa-sales-backend.onrender.com/api/agent/v1`.

2. **Taskbar key:** in Taskbar, open **Settings > AI & integrations** and create a key. API address: `https://mlsxmivbfnabqtfrlmdg.supabase.co/functions/v1/agent-api/v1`.

3. In Kairos, **Tool Store > Tabs**, install **PSA Command** and review the code prompt. Open it, go to **Connections**, paste each address and key, **Save**, then **Test**.

4. Use read-only keys until the overview looks right, then switch to write keys to make changes. An administrator PSA key is needed for rep breakdowns, reassignment and closes this month.



## Use the tools in Kairos chat and agents



**One click:** after saving your connections, open **Connections > Use these tools in Kairos chats**, paste the keys once more and press **Add to Kairos chats** (Kairos administrator only). Then start a new chat. Kairos chats can only use tools from servers added in Tool Store, so the tab itself cannot give a chat its tools without this step.



**By hand:** the tab's operations are also a local MCP server, `mcp_bridge.py` in the installed tab folder (`<Kairos data folder>/tabs/psa_command/`) (standard library Python only, no listener). In **Tool Store**, add a local (stdio) MCP server:



- **Command:** the Python that runs Kairos (the card's **Set up by hand** shows the exact path)

- **Arguments:** `<Kairos data folder>/tabs/psa_command/mcp_bridge.py --psa-url <PSA API address> --taskbar-url <Taskbar API address>` (leave out either system you do not use)

- **Key:** your PSA key and Taskbar key separated by a space (`psak_... tbk_...`). Kairos stores it encrypted and starts the bridge with only that key in its environment.



Tools: `sales_overview` (both systems as one), `psa_connection`, `psa_pipeline`, `psa_team`, `psa_accounts`, `psa_commissions`, `psa_schools`, `psa_school`, `psa_tasks`, `psa_outreach`, `psa_create_task`, `psa_update_task`, `psa_update_school`, `psa_assign_schools`, `psa_log_activity`, `taskbar_connection`, `taskbar_programs`, `taskbar_members`, `taskbar_tasks`, `taskbar_task`, `taskbar_create_task`, `taskbar_update_task`. Only tools for connected systems are listed.



Safety: every write tool first returns a plain-language preview and changes nothing; the assistant must show it and call again with `confirm: true` only after you approve (Kairos also asks before running tools you have not pre-approved). Results are prefixed as untrusted data and the server instructions tell the model never to follow instructions found in records. Tools only call fixed API paths on the addresses you configured, refuse redirects and require HTTPS (plain HTTP only for localhost). With explicit outreach permissions, the agent can queue a frozen batch after the mailbox owner approves it in the private Kairos review panel. No tool can approve itself.



The key stays in two places if you use both the tab and chat tools: the tab's encrypted store and the MCP server's encrypted key. Revoke keys in PSA Sales and Taskbar when you remove either.



## Updates



PSA Command installs into your Kairos data folder, not the app folder, so Kairos updates and reinstalls leave it and its saved connections alone. It never updates itself: when a new version is published, the Tool Store shows **Update available** and nothing changes until you choose **Update**.



## Files



`tab.json` manifest (hooks `start`, `stop`, `home_cards`); `catalog.py` shared clients, tool catalog, validation, previews and overview (no Kairos imports); `service.py` encrypted connections, snapshot cache, tool runner, chat briefing; `routes.py` `/api/tab-psa-command/...` (all `require_user`); `hooks.py` background refresh and Home cards; `view.js`/`view.css` the page; `mcp_bridge.py` the chat tools.



## Approve-once campaigns (local draft, 2026-11-08)

Ask Kairos to prepare a campaign using explicit school IDs, a saved introduction template/revision, audience, optional sequence/revision, cap and dates. In Outreach > Campaigns, review each merged introduction and follow-up/PDF and authorize once. The separate worker queues only those approved contacts and automatically enrolls follow-ups only after recording the introduction. A newly found school is never silently added. You can pause, explicitly resume an employee-paused campaign, permanently cancel, and read the operational summary here. Agents can prepare/read/pause/cancel but cannot approve or resume.

This requires the new approved-campaign migration and compatible worker/API code. `CAMPAIGN_AUTOMATION_ENABLED` defaults false; no live campaign is enabled by these source changes. Changed template/sequence/sender, revoked delegation, expiry, feedback and uncertain outcomes block dispatch. Error pauses need a new reviewed campaign; only a deliberate employee pause can resume the same authorization. SMTP already in flight may finish. Summaries stay in PSA/Kairos; no external summary delivery is configured.


## Task-based navigation (local 1.3.1 usability pass)

Email outreach opens with Start here, a three-step guide and action cards. Review & send groups Whole campaigns, One-time email requests, Follow-up plans and Sending progress, each with a short purpose statement. School replies and Templates & PDFs remain separate. Campaign results show readable counts rather than a raw response object; advanced details remain available. Manual connection fields are under advanced setup. Connection permissions, human approval separation, expiry, revocation and send safeguards are unchanged. The installed source needs fingerprint approval/restart before activation; no live account was connected for the isolated renderer review.

## Host-style dashboard (local 1.3.2)

The existing PSA Command tab now uses a portfolio-first overview: real school-stage counts, due follow-ups, overdue work, team ownership and recent activity. The layout borrows the reference dashboard hierarchy, while colors, surfaces, controls and type inherit Kairos appearance tokens. No fabricated revenue chart or performance rate is shown. Missing connections and fetch errors remain visible. Small screens stack the overview and keep operational tables horizontally scrollable.

The PSA website calls integrations AI rather than assuming a specific provider. PSA Command still uses Kairos-specific labels for real Kairos actions such as opening its chat. Existing tab slug, saved connections, permissions and review/approval flows remain unchanged. Source changes require the normal fingerprint approval/restart before the installed tab can activate them; local renderer fixtures contain fictional data only.

## Mobile and any-chat workflows (local 1.4.0)

Phone navigation uses labeled section/action selectors, stacked metrics and rep summary cards. The host theme remains inherited. Both MCP bridges now include the fixed business-operation catalog for school/contact edits, reviewed ownership changes, discovery, maps, templates/PDF uploads, sequence definitions, seasonal commissions and team administration. A capability check reports which endpoints exist and which operations the connected key may use.

Any existing or new Kairos chat can use the same connection after the person selects PSA Command in that chat's Integrations menu. Adding a server is not global chat selection. Tool Store holds new/changed tools for review; this tab does not accept those changes or alter other chats. Administrator management requires explicitly delegated library:manage, commissions:manage or team:manage. Older keys gain none of them. Private sending approvals, mail/account credentials and API-key delegation are not model tools. The person reviews final sends through the private tab controls; the assistant never receives its website JWT.

Threaded replies can now be prepared as agent drafts, reviewed by the mailbox owner, and executed through the same idempotent, delegated queue as introductions. Local tests use fictional data and fake SMTP only. Actual activation still requires source approval and compatible backend release; new Python source also needs a Kairos restart when already mounted.
