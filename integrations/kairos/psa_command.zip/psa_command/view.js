import { api, el, toast, confirmDialog, emptyState } from "/static/js/api.js";
import { mountSessionChat } from "/static/js/sessionChat.js";

const BASE = "/api/tab-psa-command";
const LABEL = { psa: "PSA Sales", taskbar: "Taskbar" };

function when(value) {
  if (!value) return "No due date";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? String(value) : date.toLocaleDateString([], { month: "short", day: "numeric" });
}
function field(label, control) {
  if (!control.id) control.id = "psa-field-" + Math.random().toString(36).slice(2);
  return el("div", { class: "field" }, [el("label", { text: label, for: control.id }), control]);
}
function options(select, rows, placeholder) {
  select.replaceChildren(el("option", { value: "", text: placeholder }),
    ...rows.map(([value, text]) => el("option", { value: String(value), text })));
}
function isoFromDate(value) {
  // A date input gives a local calendar day; send end of that day with its offset.
  if (!value) return null;
  return new Date(value + "T17:00:00").toISOString();
}

export async function render(container) {
  container.replaceChildren();
  let disposed = false, mode = "overview", data = null, settings = null, closeChat = () => {}, loadToken = 0;
  let nativePane='requests',nativeToken=0,nativePage=1;
  const wrap = el("div", { class: "view-constrained psa-view" });
  const actions = el("div", { class: "psa-actions" });
  const heading = el("div", { class: "view-header" }, [
    el("div", {}, [el("h2", { text: "PSA Command" }),
      el("div", { class: "sub", text: "PSA Sales and Taskbar in one place. Every change is confirmed before it is sent." })]),
    actions,
  ]);
  const tabs = el("nav", { class: "psa-tabs", "aria-label": "PSA Command sections" });
  const content = el("div");
  const chatHost = el("div", { class: "psa-chat card", hidden: true });
  wrap.append(heading, tabs, content, chatHost);
  container.append(wrap);

  function button(text, action, kind = "") {
    const node = el("button", { class: "btn " + kind, text, type: "button" });
    node.addEventListener("click", async () => {
      if (node.disabled) return;
      node.disabled = true;
      try { await action(); }
      catch (error) { toast(error.message || "Something went wrong", "error"); }
      finally { node.disabled = false; }
    });
    return node;
  }

  const human=(method,path,body=null,params=null)=>api(BASE+'/human-request',{method:'POST',body:JSON.stringify({method,path,body,params})});
  const confirmedTool=async(tool,args)=> (await api(BASE+'/action',{method:'POST',body:JSON.stringify({tool,arguments:args,confirmed:true})})).result;
  function nativeConnectionCard() {
    const card=el('section',{class:'card psa-native-connect'},[el('h3',{text:'Sign in to PSA inside Kairos'}),el('p',{class:'meta',text:'Your password is used once and is not saved. Human approval stays separate from your agent key. PSA sessions currently last 12 hours; sign in again here when needed.'})]);
    const form=el('form',{class:'psa-native-form'});
    const url=el('input',{value:settings?.psa?.url||'https://psa-sales-backend.onrender.com/api/agent/v1',type:'url',required:true});
    const email=el('input',{type:'email',autocomplete:'username',required:true});
    const password=el('input',{type:'password',autocomplete:'current-password',required:true});
    const create=el('input',{type:'checkbox',checked:true});
    const scope=el('select');options(scope,[['read','Read CRM records'],['write','Read and update CRM records']],'Choose CRM access');scope.value='read';
    const caps=[];
    form.append(field('PSA API address',url),field('PSA email',email),field('PSA password',password));
    const grants=el('fieldset',{},[el('legend',{text:'Permissions for a new agent connection'}),field('CRM access',scope)]);
    for(const [cap,label] of Object.entries({'schools:import':'Import reviewed schools and contacts','outreach:read':'Read templates, PDFs, my replies and follow-up status','outreach:prepare':'Prepare outreach and check my inbox','outreach:send':'Queue only messages I explicitly approve'})){
      const box=el('input',{type:'checkbox'});caps.push([cap,box]);grants.append(el('label',{},[box,document.createTextNode(' '+label)]));
    }
    const delegate=el('input',{type:'checkbox'});
    grants.append(el('label',{},[delegate,document.createTextNode(' I explicitly delegate execution of my approved batches. My agent cannot approve itself.')]));
    const alert=el('div',{'role':'status'}),submit=el('button',{class:'btn primary',type:'submit',text:'Sign in and connect'});
    form.append(el('label',{},[create,document.createTextNode(' Create a new delegated key (turn off to renew only the human session)')]),grants,alert,submit);
    create.onchange=()=>{grants.disabled=!create.checked;};
    form.addEventListener('submit',async(event)=>{
      event.preventDefault();submit.disabled=true;alert.textContent='Connecting...';
      try{
        const result=await api(BASE+'/human-session',{method:'POST',body:JSON.stringify({url:url.value,email:email.value,password:password.value,capabilities:caps.filter(([,box])=>box.checked).map(([cap])=>cap),scope:scope.value,days:30,confirm_send:delegate.checked,create_key:create.checked})});
        if(disposed||!card.isConnected)return;
        password.value='';alert.replaceChildren(el('p',{text:'Connected as '+result.employee.name+'. Password discarded.'}));
        if(result.one_time_key){
          const secret=el('input',{type:'password',value:result.one_time_key,readOnly:true,'aria-label':'New PSA key shown once'});
          alert.append(el('p',{class:'meta',text:'Copy this new key into “Use these tools in Kairos chats” below. It is shown only now. Your tab connection is already saved.'}),secret,
            button('Copy new key',()=>navigator.clipboard.writeText(secret.value),'quiet'),button('Hide key',()=>{secret.value='';alert.replaceChildren(el('p',{text:'Connection saved. Key hidden.'}));},'quiet'));
        }
        settings=await api(BASE+'/settings');submit.textContent='Connected';submit.disabled=true;
      }catch(error){password.value='';alert.textContent=error.message;submit.disabled=false;}
    });
    card.append(form);
    api(BASE+'/human-session').then(status=>{
      if(disposed||!card.isConnected)return;
      if(status.key_id){create.checked=false;grants.disabled=true;email.value=status.employee.email;}
      if(status.connected){
        card.prepend(el('p',{class:'meta',text:'Human session: '+status.employee.name+' · expires '+new Date(status.expires_at).toLocaleString()}));
        card.append(button('Sign out of approval session',async()=>{await api(BASE+'/human-session',{method:'DELETE'});draw();},'quiet'),el('p',{class:'meta',text:'Signing out stops local approvals. The separate agent key remains delegated until revoked or expired.'}));
        card.append(button('Revoke this Kairos connection',async()=>{
          const ok=await confirmDialog({title:'Revoke delegated access?',message:'This connection will stop being able to run pending outreach. A message already being sent may finish. Other keys are unchanged.',confirmLabel:'Revoke connection'});
          if(!ok)return;
          await api(BASE+'/human-session/revoke',{method:'POST'});
          settings=await api(BASE+'/settings');draw();
        },'quiet'));
        const appPassword=el('input',{type:'password',autocomplete:'new-password','aria-label':'Gmail app password'});
        card.append(el('h4',{text:'Mailbox connection'}),el('p',{class:'meta',text:'Save a Gmail app password to PSA without opening its website. Kairos does not retain it.'}),field('Gmail app password',appPassword),button('Save mailbox connection',async()=>{try{await human('POST','/api/email-settings',{email_password:appPassword.value});toast('Mailbox settings saved. Check your inbox before sending.');}finally{appPassword.value='';}},'quiet'));
      }
    }).catch(error=>{if(card.isConnected)alert.textContent=error.message;});
    return card;
  }

  function plainMail(row) {
    const card=el('details',{class:'card psa-native-message'});
    card.append(el('summary',{text:(row.email||'')+' · '+(row.school_name||'')+(row.eligible===false?' · Skipped':'')}),
      el('strong',{text:row.subject||''}),el('pre',{text:row.body_text||row.body||''}),
      el('p',{class:'meta',text:'PDFs: '+((row.attachments||[]).join(', ')||'None')}));
    if(row.blockers?.length)card.append(el('p',{text:row.blockers.join(', ')}));
    return card;
  }

  async function drawOutreach() {
    const version=++nativeToken;
    const host=el('div',{class:'psa-native-panel'});content.replaceChildren(host);
    const active=()=>!disposed&&host.isConnected&&version===nativeToken&&mode==='outreach';
    host.append(el('p',{role:'status',text:'Loading PSA workspace...'}));
    try{
      const session=await api(BASE+'/human-session');if(!active())return;
      if(!session.connected){host.replaceChildren(nativeConnectionCard());return;}
      const controls=el('nav',{class:'psa-tabs','aria-label':'PSA outreach sections'});
      for(const [key,label] of [['requests','Agent requests'],['followups','Follow-up sequences'],['progress','Sending progress'],['inbox','Replies'],['library','Templates & PDFs']])controls.append(button(label,()=>{nativePane=key;nativePage=1;drawOutreach();},nativePane===key?'primary':'quiet'));
      const body=el('div',{class:'psa-native-stack'});
      host.replaceChildren(el('h3',{text:'Outreach as '+session.employee.name}),el('p',{class:'meta',text:'Review and operate here. No PSA website tab is needed.'}),controls,body);
      if(nativePane==='requests'){
        const list=await human('GET','/api/agent-outreach-drafts',null,{page:nativePage});if(!active())return;
        body.append(el('p',{class:'meta',text:list.total+' requests'}));
        if(!list.items.length)body.append(el('p',{text:'No requests yet. Ask Kairos to prepare outreach using your saved PSA connection.'}));
        const pager=el('div',{class:'psa-actions'}),prev=button('Previous',()=>{nativePage--;drawOutreach();}),next=button('Next',()=>{nativePage++;drawOutreach();});prev.disabled=nativePage===1;next.disabled=nativePage*25>=list.total;pager.append(prev,next);body.append(pager);
        for(const item of list.items){
          const row=el('section',{class:'card'},[el('h4',{text:item.key_name+' · '+item.status}),el('p',{class:'meta',text:'Expires '+new Date(item.expires_at).toLocaleString()})]);
          row.append(button('Review request',async()=>{
            const draft=await human('GET','/api/agent-outreach-drafts/'+item.id);if(!active())return;
            const review=el('div',{class:'psa-native-stack'}),messages=draft.preview?.previews||[];
            review.append(el('p',{text:messages.filter(r=>r.eligible).length+' eligible recipients. Campaign: '+(draft.preview?.campaign?.name||'Standard outreach')}),...messages.map(plainMail));
            const ack=el('input',{type:'checkbox'});
            const approve=button(draft.key_id===session.key_id?'Approve and queue this batch':'Approve for the originating agent',async()=>{
              await human('POST','/api/agent-outreach-drafts/'+draft.id+'/approve',{revision:draft.revision});
              if(draft.key_id===session.key_id)await confirmedTool('psa_execute_approved_outreach',{draft_id:draft.id});
              toast('Approval saved. Check sending progress for queue status.');drawOutreach();
            },'primary');
            if(draft.status==='approved' && draft.key_id===session.key_id && draft.can_execute && Date.parse(draft.expires_at)>Date.now()) {
              review.append(button('Queue this approved batch',async()=>{
                await confirmedTool('psa_execute_approved_outreach',{draft_id:draft.id});
                toast('Approved batch queued.');drawOutreach();
              },'primary'));
            }
            approve.disabled=true;
            ack.onchange=()=>{approve.disabled=!ack.checked||draft.status!=='awaiting'||!draft.key_active||!draft.can_execute||Date.parse(draft.expires_at)<=Date.now()||!messages.some(r=>r.eligible);};
            review.append(el('label',{},[ack,document.createTextNode(' I reviewed the exact recipients, messages and PDFs and authorize this batch from my mailbox.')]),approve,
              button('Refresh review',async()=>{await human('POST','/api/agent-outreach-drafts/'+draft.id+'/refresh',{revision:draft.revision});drawOutreach();},'quiet'),
              button('Revoke remaining messages',async()=>{await human('POST','/api/agent-outreach-drafts/'+draft.id+'/revoke',{revision:draft.revision});drawOutreach();},'quiet'));
            row.replaceChildren(el('h4',{text:draft.key_name+' · '+draft.status}),review);
          },'quiet'));body.append(row);
        }
      }else if(nativePane==='progress'){
        const [batches,worker]=await Promise.all([run('psa_outreach',{scope:'mine',limit:25}),human('GET','/api/outreach/worker')]);if(!active())return;
        body.append(el('p',{role:'status',text:worker.online?'Separate worker online':'Separate worker offline. Saved mail waits; this tab does not send in a web thread.'}));
        if(!batches.items?.length)body.append(el('p',{text:'No batches yet.'}));
        for(const batch of batches.items||[]){const row=el('section',{class:'card'},[el('h4',{text:'Batch #'+batch.id+' · '+batch.status})]);
          row.append(button('Read progress',async()=>{const detail=await run('psa_outreach_batch',{batch_id:batch.id});if(active())row.append(el('pre',{text:JSON.stringify(detail,null,2)}));},'quiet'),button('Stop remaining messages',()=>perform('psa_cancel_outreach',{batch_id:batch.id}),'quiet'));body.append(row);}
      }else if(nativePane==='inbox'){
        body.append(button('Check my inbox',async()=>{await confirmedTool('psa_check_replies',{});drawOutreach();},'quiet'));
        const replies=await run('psa_replies',{page:nativePage,limit:25});if(!active())return;
        if(!replies.items?.length)body.append(el('p',{text:'No replied conversations found. Use Check my inbox to sync.'}));
        for(const reply of replies.items||[])body.append(button(reply.school_name+' · '+reply.school_email,async()=>{const chain=await run('psa_reply_chain',{email_id:reply.id});if(active())body.append(el('pre',{class:'card',text:JSON.stringify(chain,null,2)}));},'quiet'));
        const more=button('Next replies',()=>{nativePage++;drawOutreach();});more.disabled=nativePage*25>=replies.total;body.append(more);
      }else if(nativePane==='library')await drawNativeLibrary(body,active,session.employee.admin);
      else await drawNativeFollowups(body,active,session.employee.admin);
    }catch(error){if(active())host.replaceChildren(el('p',{role:'alert',text:error.message}),button('Retry',drawOutreach,'quiet'),nativeConnectionCard());}
  }

  async function drawNativeFollowups(body,active,admin) {
    const [definitions,originals,enrollments]=await Promise.all([human('GET','/api/outreach/sequences'),human('GET','/api/outreach/sequence-originals',null,{page:nativePage,per_page:50}),human('GET','/api/outreach/sequence-enrollments',null,{page:nativePage,per_page:50})]);
    if(!active())return;
    if(admin){
      const templates=await human('GET','/api/outreach/templates');if(!active())return;
      const form=el('details',{class:'card'},[el('summary',{text:'Create follow-up sequence'})]),name=el('input',{placeholder:'Sequence name','aria-label':'Sequence name'}),audience=el('select');
      options(audience,[['all','All contacts'],['principal_ap','Principal / AP'],['pta_pto','PTA / PTO'],['enrichment','Enrichment'],['trunk_or_treat','Trunk-or-Treat']],'Choose audience');audience.value='principal_ap';
      const refs=[1,2,3].map(number=>{const select=el('select'),day=el('input',{type:'number',min:1,max:90,value:[4,10,17][number-1]});form.append(field('Step '+number+' template',select),field('Step '+number+' days from intro',day));return {select,day};});
      const update=()=>refs.forEach(({select},i)=>options(select,templates.items.filter(t=>t.kind==='followup'&&t.step===i+1&&['general',audience.value].includes(t.audience)).map(t=>[t.id,t.name+' · v'+t.revision]),'Choose template'));
      audience.onchange=update;update();form.prepend(field('Sequence name',name),field('Audience',audience));
      form.append(el('p',{class:'meta',text:'Weekdays, 9am to 5pm Eastern. Enrollment still requires a separate approval.'}),button('Create versioned sequence',async()=>{
        const steps=refs.map(({select,day})=>{const t=templates.items.find(t=>t.id===Number(select.value));if(!t)throw new Error('Choose all three templates');return {day:Number(day.value),template_id:t.id,template_revision:t.revision};});
        await human('POST','/api/outreach/sequences',{name:name.value,audience:audience.value,start_hour:9,end_hour:17,steps});drawOutreach();
      },'primary'));body.append(form);
    }
    body.append(el('p',{class:'meta',text:'Introductions never enroll automatically. Review the contact, each message/PDF, dates and mode here. Automatic mode requires your separate acknowledgment.'}));
    const sequence=el('select');options(sequence,definitions.items.filter(s=>!s.archived).map(s=>[s.id,s.name+' · v'+s.revision]),'Choose sequence');
    const today=(days=0)=>new Date(Date.now()+days*86400000).toLocaleDateString('en-CA',{timeZone:'America/New_York'});
    const starts=el('input',{type:'date',value:today()}),ends=el('input',{type:'date',value:today(45)}),sending=el('select');
    options(sending,[['review','Review each due step'],['automatic','Authorize these scheduled steps until the end date']],'Choose mode');sending.value='review';
    const replace=el('input',{type:'checkbox'}),chosen=new Set(),pick=el('div',{class:'psa-native-stack'}),reviewHost=el('div',{class:'psa-native-stack'});
    for(const original of originals.items){const box=el('input',{type:'checkbox'});box.onchange=()=>box.checked?chosen.add(original.id):chosen.delete(original.id);pick.append(el('label',{},[box,document.createTextNode(' '+original.school_name+' · '+original.email+(original.already_managed?' · Already enrolled':''))]));}
    const search=el('input',{type:'search',placeholder:'Search school or recipient','aria-label':'Search introductions'}),searchResults=el('div');
    const searchButton=button('Search introductions',async()=>{
      const result=await human('GET','/api/outreach/sequence-originals',null,{q:search.value,page:1,per_page:100});if(!active())return;
      chosen.clear();pick.replaceChildren();
      for(const original of result.items){const box=el('input',{type:'checkbox'});box.onchange=()=>box.checked?chosen.add(original.id):chosen.delete(original.id);pick.append(el('label',{},[box,document.createTextNode(' '+original.school_name+' · '+original.email)]));}
      searchResults.textContent=result.total+' matching introductions (showing up to 100). Narrow the search for more.';
    },'quiet');
    body.append(field('Sequence',sequence),field('Start date (Eastern)',starts),field('Authorization end date (Eastern)',ends),field('Mode',sending),
      el('label',{},[replace,document.createTextNode(' Replace existing enrollments with a newly reviewed approval. Sent steps will not repeat.')]),search,searchButton,searchResults,pick,
      button('Preview all scheduled messages',async()=>{
        const definition=definitions.items.find(s=>s.id===Number(sequence.value));
        if(!definition||!chosen.size)throw new Error('Choose a sequence and introductions');
        const settings={sequence_id:definition.id,revision:definition.revision,original_ids:[...chosen],mode:sending.value,start_date:starts.value,end_date:ends.value,replace_existing:replace.checked};
        const preview=await human('POST','/api/outreach/sequence-enrollments/preview',settings);if(!active())return;
        const acknowledgement=el('input',{type:'checkbox'}),commit=button(settings.mode==='automatic'?'Authorize these scheduled sends':'Enroll for reviewed follow-ups',async()=>{
          await human('POST','/api/outreach/sequence-enrollments/commit',{review_id:preview.review_id,settings,...(settings.mode==='automatic'?{confirm:'AUTHORIZE_AUTOMATIC_SEQUENCE'}:{})});
          toast('Enrollment saved. The separate worker enforces the approved rules.');drawOutreach();
        },'primary');commit.disabled=true;acknowledgement.onchange=()=>{commit.disabled=!acknowledgement.checked;};
        reviewHost.replaceChildren(el('p',{text:'Frozen '+settings.mode+' enrollment: '+preview.starts_at+' to '+preview.ends_at}),...preview.rows.flatMap(row=>row.steps.map(step=>{
          const mail=plainMail({...step,email:row.email,school_name:row.school_name});mail.append(el('p',{class:'meta',text:step.already_sent?'Already sent; will not repeat':'Due '+new Date(step.due_at).toLocaleString()+' · day '+step.day}));return mail;
        })),el('label',{},[acknowledgement,document.createTextNode(settings.mode==='automatic'?' I authorize these exact messages, contacts, dates and business hours to send automatically from my mailbox.':' I reviewed the messages and dates. Every due step will still need my approval.')]),commit);
      },'primary'),reviewHost,el('h3',{text:'My enrollments'}));
    for(const enrollment of enrollments.items){
      const card=el('section',{class:'card'},[el('h4',{text:enrollment.school_name+' · '+enrollment.status}),el('p',{text:enrollment.reason||enrollment.mode})]);
      for(const step of enrollment.steps){
        card.append(el('p',{text:'Step '+step.number+' · '+step.status+' · '+new Date(step.due_at).toLocaleString()}));
        if(enrollment.status==='active'&&enrollment.mode==='review'&&step.status==='waiting')card.append(button('Review step '+step.number,async()=>{
          const preview=await human('POST','/api/outreach/sequence-steps/'+step.id+'/preview',{});if(!active())return;
          const mail=plainMail(preview);mail.open=true;
          mail.append(button('Approve this due message',async()=>{await human('POST','/api/outreach/sequence-steps/'+step.id+'/approve',{preview_token:preview.preview_token});toast('Step approved for 15 minutes within its business window.');drawOutreach();},'primary'));card.append(mail);
        },'quiet'));
      }
      if(enrollment.status==='active')card.append(button('Revoke remaining follow-ups',async()=>{await human('POST','/api/outreach/sequence-enrollments/'+enrollment.id+'/cancel',{});drawOutreach();},'quiet'));
      body.append(card);
    }
    const prev=button('Previous conversations / enrollments',()=>{nativePage--;drawOutreach();}),next=button('Next conversations / enrollments',()=>{nativePage++;drawOutreach();});prev.disabled=nativePage===1;next.disabled=nativePage*50>=Math.max(originals.total,enrollments.total);body.append(el('div',{class:'psa-actions'},[prev,next]));
  }

  async function drawNativeLibrary(body,active,admin) {
    const [templates,assets]=await Promise.all([human('GET','/api/outreach/templates'),human('GET','/api/outreach/template-assets')]);if(!active())return;
    body.append(el('h3',{text:'Shared templates and attachment catalog'}));
    for(const template of templates.items)body.append(plainMail({...template,school_name:template.name,email:template.audience,attachments:(template.attachments||[]).map(a=>a.name)}));
    body.append(el('p',{class:'meta',text:'Catalog PDFs: '+(assets.saved.map(a=>a.name).join(', ')||'None yet')}));
    if(!admin){body.append(el('p',{text:'Ask Kairos to use a saved template or choose catalog PDFs when preparing outreach.'}));return;}
    function uploadPicker(kind,label){
      const input=el('input',{type:'file',accept:kind==='pdf'?'.pdf':'.json',hidden:true}),output=el('div',{role:'status'}),pick=button(label,()=>input.click(),'quiet');
      input.addEventListener('change',async()=>{
        const file=input.files[0];if(!file)return;
        pick.disabled=true;output.textContent='Uploading '+file.name+'...';
        try{
          const cap=kind==='pdf'?10*1024*1024:1024*1024;if(file.size>cap)throw new Error('File exceeds the upload size limit');
          const bytes=new Uint8Array(await file.arrayBuffer());let binary='';for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));
          const result=await api(BASE+'/human-upload',{method:'POST',body:JSON.stringify({kind,filename:file.name,encoded:btoa(binary)})});if(!active())return;
          if(kind==='pdf'){toast('PDF saved in the shared catalog.');drawOutreach();}
          else output.replaceChildren(el('p',{text:result.new+' new templates; '+result.total+' rows reviewed.'}),...result.items.map(item=>el('p',{text:item.name+' · '+item.action})),button('Import reviewed templates',async()=>{await human('POST','/api/outreach/template-imports/'+result.id+'/commit',{});drawOutreach();},'primary'));
        }catch(error){if(active())output.textContent=error.message;}finally{pick.disabled=false;input.value='';}
      });return el('div',{class:'card'},[input,pick,output]);
    }
    body.append(uploadPicker('pdf','Add PDF to shared catalog'),uploadPicker('templates','Upload template JSON for review'),
      button('Import approved Winter 2027 template set',async()=>{await human('POST','/api/outreach/templates/seed-winter-2027',{});drawOutreach();},'quiet'));
    const form=el('section',{class:'card psa-native-form'},[el('h4',{text:'Create or update template'})]),choose=el('select'),name=el('input'),subject=el('input'),copy=el('textarea',{rows:10}),kind=el('select'),audience=el('select'),step=el('select'),archive=el('input',{type:'checkbox'});
    options(choose,templates.items.map(t=>[t.id,t.name+' · v'+t.revision]),'New template');options(kind,[['initial','Introduction'],['followup','Follow-up']],'Choose type');kind.value='initial';
    options(audience,[['general','General'],['principal_ap','Principal / AP'],['pta_pto','PTA / PTO'],['enrichment','Enrichment'],['trunk_or_treat','Trunk-or-Treat']],'Choose audience');audience.value='general';options(step,[[0,'Intro'],[1,'Follow-up 1'],[2,'Follow-up 2'],[3,'Follow-up 3']],'Choose step');step.value='0';
    const checks=assets.saved.map(a=>[a,el('input',{type:'checkbox'})]);let current=null;
    choose.onchange=()=>{current=templates.items.find(t=>t.id===Number(choose.value));name.value=current?.name||'';subject.value=current?.subject||'';copy.value=current?.body||'';kind.value=current?.kind||'initial';audience.value=current?.audience||'general';step.value=String(current?.step||0);archive.checked=Boolean(current?.archived);checks.forEach(([a,box])=>{box.checked=Boolean(current?.attachments?.some(t=>t.id===a.id));});};
    kind.onchange=()=>{step.value=kind.value==='initial'?'0':'1';};
    form.append(field('Edit saved template',choose),field('Name',name),field('Type',kind),field('Audience',audience),field('Step',step),field('Subject',subject),field('Message',copy),el('p',{class:'meta',text:'Fields: {school name}, {contact name}, {my name}, {my email}. Selected PDFs will be included every time this template is used.'}));
    checks.forEach(([a,box])=>form.append(el('label',{},[box,document.createTextNode(' '+a.name)])));
    form.append(el('label',{},[archive,document.createTextNode(' Archive template')]),button('Save template version',async()=>{
      const values={name:name.value,kind:kind.value,audience:audience.value,step:Number(step.value),subject:subject.value,body:copy.value,attachment_ids:checks.filter(([,box])=>box.checked).map(([a])=>a.id),archived:archive.checked,...(current?{revision:current.revision}:{})};
      await human(current?'PUT':'POST','/api/outreach/templates'+(current?'/'+current.id:''),values);toast('Template version saved. Existing approved copy stays frozen.');drawOutreach();
    },'primary'));body.append(form);
  }

  async function run(tool, args) {
    return (await api(BASE + "/action", { method: "POST", body: JSON.stringify({ tool, arguments: args }) })).result;
  }

  // Writes: ask the server for a preview, show it, send only after the person agrees.
  async function perform(tool, args) {
    const preview = await run(tool, args);
    const summary = preview?.summary || "Send this change?";
    const ok = await confirmDialog({ title: "Confirm change in " + (preview?.system || "PSA"), message: summary,
      confirmLabel: "Send change", danger: false });
    if (!ok) return false;
    await api(BASE + "/action", { method: "POST", body: JSON.stringify({ tool, arguments: args, confirmed: true }) });
    toast("Done. " + summary);
    await load(false);
    return true;
  }

  function drawTabs() {
    tabs.replaceChildren(...[["overview", "Overview"], ["outreach", "Outreach"], ["actions", "Actions"], ["connections", "Connections"]].map(([key, text]) =>
      el("button", { class: "btn quiet" + (mode === key ? " active" : ""), text, type: "button",
        "aria-pressed": String(mode === key), onclick: () => { mode = key; draw(); } })));
  }

  async function load(refresh) {
    const token = ++loadToken;
    content.replaceChildren(el("div", { class: "meta", text: refresh ? "Refreshing from PSA Sales and Taskbar..." : "Loading..." }));
    try {
      const [nextSettings, nextData] = await Promise.all([
        api(BASE + "/settings"), api(BASE + "/overview" + (refresh ? "?refresh=true" : "")),
      ]);
      if (disposed || token !== loadToken) return;
      settings = nextSettings; data = nextData;
      if (!settings.psa.key_saved && !settings.taskbar.key_saved && mode === "overview") mode = "connections";
      draw();
    } catch (error) {
      if (disposed || token !== loadToken) return;
      content.replaceChildren(el("div", { class: "card psa-error" }, [
        el("div", { class: "title", text: "PSA Command could not load" }),
        el("div", { class: "meta", text: (error.message || "Request failed") + ". Check your connection, then retry." }),
        button("Retry", () => load(true)),
      ]));
    }
  }

  function systemStatus(system) {
    const part = data?.[system] || {};
    if (!part.connected) return el("span", { class: "psa-pill", text: LABEL[system] + ": not connected" });
    if (part.error) return el("span", { class: "psa-pill warn", text: LABEL[system] + ": " + part.error });
    const who = [part.me?.name, part.me?.role, part.me?.workspace].filter(Boolean).join(" · ");
    return el("span", { class: "psa-pill ok", text: LABEL[system] + (who ? ": " + who : "") });
  }

  function stat(value, label) {
    return el("div", { class: "card psa-stat" }, [el("strong", { text: value ?? "–" }), el("span", { class: "meta", text: label })]);
  }

  function taskRow(system, task) {
    const meta = [when(task.due_at), task.owner, task.school, task.status].filter(Boolean).join(" · ");
    const row = el("div", { class: "psa-row" }, [
      el("div", { class: "psa-row-text" }, [el("div", { class: "title", text: task.title || "Untitled task" }),
        el("div", { class: "meta", text: meta })]),
    ]);
    const done = system === "psa"
      ? () => perform("psa_update_task", { task_id: task.id, version: task.version, status: "completed" })
      : () => perform("taskbar_update_task", { task_id: task.id, revision: task.revision, status: "Completed" });
    if (task.id && (task.version || task.revision)) row.append(button("Mark done", done, "quiet"));
    return row;
  }

  function overdueColumn(system) {
    const part = data?.[system] || {};
    const column = el("div", { class: "card psa-column" }, [
      el("div", { class: "psa-column-head" }, [el("div", { class: "title", text: LABEL[system] + " overdue" }),
        el("span", { class: "meta", text: part.connected && !part.error ? String(part.overdue_total ?? 0) : "" })]),
    ]);
    if (!part.connected) column.append(el("div", { class: "meta", text: "Connect " + LABEL[system] + " under Connections." }));
    else if (part.error) column.append(el("div", { class: "meta psa-warn", text: part.error }));
    else if (!(part.overdue_tasks || []).length) column.append(el("div", { class: "meta", text: "Nothing overdue." }));
    else column.append(...part.overdue_tasks.slice(0, 25).map((task) => taskRow(system, task)));
    return column;
  }

  function drawOverview() {
    const psa = data?.psa || {}, taskbar = data?.taskbar || {};
    const nodes = [el("div", { class: "psa-status" }, [systemStatus("psa"), systemStatus("taskbar"),
      el("span", { class: "meta", text: data?.generated_at ? "Updated " + new Date(data.generated_at).toLocaleTimeString() : "" })])];
    nodes.push(el("div", { class: "psa-stats" }, [
      stat(psa.totals?.schools, "schools in PSA"),
      stat(psa.closes_this_month, "closes this month"),
      stat(psa.connected && !psa.error ? psa.overdue_total : null, "overdue PSA tasks"),
      stat(taskbar.connected && !taskbar.error ? taskbar.overdue_total : null, "overdue Taskbar tasks"),
    ]));
    if ((psa.reps || []).length) {
      const table = el("table", { class: "psa-table" }, [
        el("thead", {}, [el("tr", {}, ["Rep", "Schools", "Pipeline", "Clients", "Closed this month", "Overdue"].map((h) => el("th", { text: h })))]),
        el("tbody", {}, psa.reps.map((rep) => el("tr", {}, [rep.name, rep.schools, rep.pipeline, rep.active_clients,
          rep.closes_this_month, rep.overdue_tasks].map((v, i) => el("td", { text: String(v ?? 0), class: i && rep.overdue_tasks && i === 5 ? "psa-warn" : "" }))))),
      ]);
      nodes.push(el("div", { class: "card psa-scroll" }, [el("div", { class: "title", text: "Pipeline and accounts by rep" }), table]));
    } else if (psa.connected && !psa.error && !psa.admin) {
      nodes.push(el("div", { class: "meta", text: "Rep breakdowns need a PSA Sales administrator key." }));
    }
    nodes.push(el("div", { class: "psa-split" }, [overdueColumn("psa"), overdueColumn("taskbar")]));
    const activity = psa.activity || [];
    nodes.push(el("div", { class: "card" }, [el("div", { class: "title", text: "Recent sales activity" }),
      ...(activity.length ? activity.map((item) => el("div", { class: "psa-row" }, [el("div", { class: "psa-row-text" }, [
        el("div", { text: [item.actor, item.kind, item.school].filter(Boolean).join(" · ") }),
        el("div", { class: "meta", text: (item.detail || "") + (item.at ? " · " + when(item.at) : "") })])]))
        : [el("div", { class: "meta", text: psa.connected ? "No recent activity." : "Connect PSA Sales to see activity." })])]));
    content.replaceChildren(...nodes);
  }

  function schoolPicker() {
    const query = el("input", { type: "search", placeholder: "Search schools by name, contact or email" });
    const select = el("select", { "aria-label": "School" });
    options(select, [], "Search first");
    const find = button("Search", async () => {
      const result = await run("psa_schools", { q: query.value.trim(), limit: 25 });
      const rows = (result.items || []).map((s) => [s.id, [s.school_name, s.owner_name, s.status].filter(Boolean).join(" · ")]);
      options(select, rows, rows.length ? "Choose a school" : "No matches");
    });
    return { select, node: el("div", { class: "psa-pair" }, [field("Find school", query), find]) };
  }

  function repOptions(select, placeholder) {
    options(select, (data?.psa?.reps || []).map((rep) => [rep.id, rep.name]), placeholder);
  }

  function drawActions() {
    const psaOn = settings?.psa?.key_saved, taskbarOn = settings?.taskbar?.key_saved;
    const panels = [];

    // Create a task in either system.
    const system = el("select", { "aria-label": "System" });
    options(system, [psaOn && ["psa", "PSA Sales"], taskbarOn && ["taskbar", "Taskbar"]].filter(Boolean), "Choose a system");
    const title = el("input", { maxlength: 240, placeholder: "Call the director about pricing" });
    const due = el("input", { type: "date" });
    const owner = el("select", { "aria-label": "Assign to" });
    const program = el("select", { "aria-label": "Program" });
    const extra = el("div");
    options(owner, [], "Me"); options(program, [], "Choose a program");
    system.addEventListener("change", async () => {
      extra.replaceChildren();
      try {
        if (system.value === "psa") {
          repOptions(owner, "Me");
          extra.append(field("Assign to", owner));
        } else if (system.value === "taskbar") {
          const [programs, members] = await Promise.all([run("taskbar_programs", {}), run("taskbar_members", {})]);
          const list = (x) => Array.isArray(x) ? x : (x?.items || []);
          options(program, list(programs).map((p) => [p.id, p.name || p.id]), "Choose a program");
          options(owner, list(members).map((m) => [m.id, m.name || m.full_name || m.display_name || m.email || m.id]), "Default assignee");
          extra.append(field("Program", program), field("Assign to", owner));
        }
      } catch (error) { if (!disposed) toast(error.message, "error"); }
    });
    panels.push(el("div", { class: "card psa-form" }, [el("div", { class: "title", text: "Create a task" }),
      field("System", system), field("Title", title), field("Due date", due), extra,
      button("Review and send", async () => {
        if (!title.value.trim()) throw new Error("Enter a task title");
        if (system.value === "psa") {
          const args = { title: title.value.trim() };
          if (due.value) args.due_at = isoFromDate(due.value);
          if (owner.value) args.user_id = Number(owner.value);
          if (await perform("psa_create_task", args)) title.value = "";
        } else if (system.value === "taskbar") {
          if (!program.value || !due.value) throw new Error("Choose a program and due date");
          const args = { title: title.value.trim().slice(0, 140), program_id: program.value, due_at: isoFromDate(due.value) };
          if (owner.value) args.assignee = owner.value;
          if (await perform("taskbar_create_task", args)) title.value = "";
        } else throw new Error("Choose a system");
      }, "primary")]));

    if (psaOn) {
      const reassign = schoolPicker(), rep = el("select", { "aria-label": "New owner" });
      repOptions(rep, data?.psa?.admin ? "Choose a rep" : "Administrator key required");
      panels.push(el("div", { class: "card psa-form" }, [el("div", { class: "title", text: "Reassign a school" }),
        reassign.node, field("School", reassign.select), field("New owner", rep),
        button("Review and send", async () => {
          if (!reassign.select.value || !rep.value) throw new Error("Choose a school and a rep");
          await perform("psa_assign_schools", { ids: [Number(reassign.select.value)], user_id: Number(rep.value) });
        }, "primary")]));

      const logged = schoolPicker(), kind = el("select", { "aria-label": "Activity type" });
      const detail = el("textarea", { rows: 3, maxlength: 2000, placeholder: "What happened" });
      options(kind, [["call", "Call"], ["meeting", "Meeting"], ["note", "Note"]], "Choose a type");
      kind.value = "call";
      panels.push(el("div", { class: "card psa-form" }, [el("div", { class: "title", text: "Log activity" }),
        logged.node, field("School", logged.select), field("Type", kind), field("Details", detail),
        button("Review and send", async () => {
          if (!logged.select.value || !detail.value.trim()) throw new Error("Choose a school and enter details");
          if (await perform("psa_log_activity", { school_id: Number(logged.select.value), kind: kind.value, detail: detail.value.trim() })) detail.value = "";
        }, "primary")]));
    }
    content.replaceChildren(panels.length && (psaOn || taskbarOn) ? el("div", { class: "psa-grid" }, panels)
      : emptyState({ title: "Nothing connected yet", hint: "Add a PSA Sales or Taskbar key under Connections.",
        actionLabel: "Open Connections", onAction: () => { mode = "connections"; draw(); } }));
  }

  function connectionCard(system) {
    const saved = settings?.[system] || {};
    const url = el("input", { type: "url", value: saved.url || "", placeholder: system === "psa"
      ? "https://psa-sales-backend.onrender.com/api/agent/v1" : "https://<project>.supabase.co/functions/v1/agent-api/v1" });
    const key = el("input", { type: "password", autocomplete: "off",
      placeholder: saved.key_saved ? "Saved; leave blank to keep" : (system === "psa" ? "psak_..." : "tbk_...") });
    const result = el("div", { class: "meta" });
    const where = system === "psa" ? "PSA Sales Settings > AI & integrations" : "Taskbar Settings > AI & integrations";
    return el("div", { class: "card psa-form" }, [
      el("div", { class: "title", text: LABEL[system] }),
      el("div", { class: "meta", text: "Create a key in " + where + ". Start read-only; use a write key to make changes from here." }),
      field("API address", url), field("API key", key),
      el("div", { class: "psa-actions" }, [
        button("Save", async () => {
          settings = await api(`${BASE}/settings/${system}`, { method: "PUT", body: JSON.stringify({ url: url.value, key: key.value || null }) });
          key.value = ""; key.placeholder = "Saved; leave blank to keep";
          toast(LABEL[system] + " saved");
        }, "primary"),
        button("Test", async () => {
          const me = await api(`${BASE}/settings/${system}/test`, { method: "POST" });
          result.textContent = "Connected as " + [me.name, me.role].filter(Boolean).join(", ");
        }),
        saved.key_saved ? button("Disconnect", async () => {
          const ok = await confirmDialog({ title: "Disconnect " + LABEL[system] + "?", message: "The saved key is removed from Kairos. Revoke it in " + LABEL[system] + " too if you no longer need it.", confirmLabel: "Disconnect" });
          if (!ok) return;
          settings = await api(`${BASE}/settings/${system}`, { method: "PUT", body: JSON.stringify({ clear: true }) });
          draw();
        }, "quiet") : null,
      ].filter(Boolean)),
      result,
    ]);
  }

  function chatToolsCard() {
    const card = el("div", { class: "card psa-form" }, [el("div", { class: "title", text: "Use these tools in Kairos chats" }),
      el("div", { class: "meta", text: "Loading..." })]);
    (async () => {
      const setup = await api(BASE + "/chat-tools").catch(() => null);
      const servers = await api("/api/integrations").catch(() => null);
      if (disposed || !setup) return;
      const existing = (servers || []).find((item) => item.kind === "mcp_server" && item.name === setup.name);
      const manual = el("details", {}, [el("summary", { text: "Set up by hand" }),
        el("div", { class: "meta", text: "Tool Store > MCP servers > add a local (stdio) server named " + setup.name + "." }),
        el("div", { class: "meta", text: "Command:" }), el("code", { class: "psa-code", text: setup.command }),
        el("div", { class: "meta", text: "Arguments, one per line:" }), el("code", { class: "psa-code", text: setup.args.join("\n") }),
        el("div", { class: "meta", text: "Key: your PSA Sales key and Taskbar key separated by a space." })]);
      const body = [el("div", { class: "title", text: "Use these tools in Kairos chats" })];
      if (!setup.systems.length) {
        body.push(el("div", { class: "meta", text: "Save PSA Sales or Taskbar above first." }));
      } else if (existing) {
        const state = existing.status?.state, count = existing.status?.tools;
        body.push(el("div", { class: "meta", text: state === "working"
          ? `Added to Kairos with ${count ?? "its"} tools. Start a new chat and ask, for example, "create a Taskbar task for Chris".`
          : "Added to Kairos, but its last check failed: " + (existing.status?.error || "not checked yet") + "." }));
        if (setup.systems.some((system) => !existing.args?.includes(`--${system}-url`)))
          body.push(el("div", { class: "meta psa-warn", text: "It was added before every system was connected. Remove " + setup.name + " in Tool Store and add it again here." }));
        body.push(el("div", { class: "psa-actions" }, [button("Check again", async () => {
          await api(`/api/integrations/${existing.id}/check`, { method: "POST" });
          card.replaceWith(chatToolsCard());
        })]));
      } else if (servers === null) {
        body.push(el("div", { class: "meta", text: "Only a Kairos administrator can add chat tools. Ask one to add them, or follow the steps below." }));
      } else {
        const keys = Object.fromEntries(setup.systems.map((system) => [system, el("input", { type: "password", autocomplete: "off",
          placeholder: system === "psa" ? "psak_..." : "tbk_..." })]));
        body.push(el("div", { class: "meta", text: "Lets any Kairos chat read and change PSA Sales and Taskbar with the same confirmations. Paste the keys once more; Kairos stores them encrypted for the chat tools." }),
          ...setup.systems.map((system) => field(LABEL[system] + " key", keys[system])),
          el("div", { class: "psa-actions" }, [button("Add to Kairos chats", async () => {
            const values = setup.systems.map((system) => keys[system].value.trim());
            if (values.some((value, i) => !value.startsWith(setup.systems[i] === "psa" ? "psak_" : "tbk_")))
              return toast("Paste a PSA Sales key (psak_...) and a Taskbar key (tbk_...) for each connected system");
            const ok = await confirmDialog({ title: "Add PSA Command to Kairos chats?",
              message: "Kairos chats get the PSA Command tools for " + setup.systems.map((system) => LABEL[system]).join(" and ") + ". Every change still shows a preview and waits for your approval.",
              confirmLabel: "Add" });
            if (!ok) return;
            const added = await api("/api/integrations/mcp-server", { method: "POST", body: JSON.stringify({
              name: setup.name, mcp_type: "stdio", command: setup.command, args: setup.args, api_key: values.join(" ") }) });
            toast(added.status?.state === "working" ? "Added. Start a new chat to use the tools." : "Added, but the check failed. See Tool Store.");
            card.replaceWith(chatToolsCard());
          }, "primary")]));
      }
      body.push(manual);
      card.replaceChildren(...body);
    })();
    return card;
  }

  function drawConnections() {
    content.replaceChildren(nativeConnectionCard(),el("div", { class: "psa-grid" }, [connectionCard("psa"), connectionCard("taskbar"), chatToolsCard()]));
  }

  function draw() {
    if (disposed) return;
    drawTabs();
    if (mode === "connections") drawConnections();
    else if (mode === "outreach") drawOutreach();
    else if (mode === "actions") drawActions();
    else drawOverview();
  }

  async function openChat() {
    closeChat(); closeChat = () => {};
    const { session_id } = await api(BASE + "/chat", { method: "POST" });
    if (disposed) return;
    chatHost.hidden = false;
    chatHost.replaceChildren();
    const host = el("div", { class: "psa-chat-host" });
    chatHost.append(el("div", { class: "psa-column-head" }, [el("div", { class: "title", text: "Ask Kairos" }),
      button("Close", () => { closeChat(); closeChat = () => {}; chatHost.hidden = true; }, "quiet")]), host);
    closeChat = await mountSessionChat(host, { sessionId: session_id, title: "PSA Command", modelPicker: true,
      openInChats: true, placeholder: "Ask about the pipeline, overdue work or what to do next" });
    chatHost.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }

  actions.append(button("Refresh", () => load(true)), button("Ask Kairos", openChat, "primary"));
  await load(false);
  return () => { disposed = true; closeChat(); };
}
